import type React from "react"
import { useState } from "react"
import { useNavigate } from "react-router-dom"
import Header from "../components/Header"

interface VendorItem {
  id: string
  name: string
  checked: boolean
}

interface ActivityItem {
  id: number
  requirement: string
  value: string
  attachment: string
}

const RFIResponseView: React.FC = () => {
  const navigate = useNavigate()
  const [vendors, setVendors] = useState<VendorItem[]>([
    { id: "v1", name: "Divya Ojha (Vend0123)", checked: true },
    { id: "v2", name: "Divya Ojha", checked: false },
  ])

  const [activities, setActivities] = useState<ActivityItem[]>([
    { id: 1, requirement: "Laptop", value: "12", attachment: "📎" },
    { id: 2, requirement: "Mac Laptop", value: "10", attachment: "📎" },
  ])

  const handleVendorCheck = (id: string) => {
    setVendors(vendors.map((v) => (v.id === id ? { ...v, checked: !v.checked } : v)))
  }

  return (
    <>
      <Header title="RFI Response > View" />
      <div className="info-grid">
        <div className="info-field">
          <div className="info-label">RFI Number</div>
          <input type="text" defaultValue="RFI Number 1" style={{ width: "100%", padding: "8px" }} />
        </div>
        <div className="info-field">
          <div className="info-label">Regarding</div>
          <input type="text" defaultValue="Laptop" style={{ width: "100%", padding: "8px" }} />
        </div>
      </div>

      <div className="vendor-list">
        {vendors.map((vendor) => (
          <div key={vendor.id} className="vendor-item">
            <input
              type="checkbox"
              id={vendor.id}
              checked={vendor.checked}
              onChange={() => handleVendorCheck(vendor.id)}
            />
            <label htmlFor={vendor.id}>{vendor.name}</label>
          </div>
        ))}
      </div>

      <h3>RFI Filling Activity List By Vendor</h3>
      <table>
        <thead>
          <tr>
            <th>S.No</th>
            <th>Requirements</th>
            <th>Value</th>
            <th>Attachment</th>
          </tr>
        </thead>
        <tbody>
          {activities.map((activity) => (
            <tr key={activity.id}>
              <td>{activity.id}</td>
              <td>{activity.requirement}</td>
              <td>{activity.value}</td>
              <td>{activity.attachment}</td>
            </tr>
          ))}
        </tbody>
      </table>

      <div className="button-container">
        <button className="button primary">Make RFI Qualified to selected Vendor</button>
        <button className="button primary">Make RFI Qualified to All Vendor</button>
      </div>

      <div className="button-container">
        <button className="button" onClick={() => navigate("/rfi-response")}>
          Back
        </button>
        <button className="button primary">Submit</button>
      </div>
    </>
  )
}

export default RFIResponseView

