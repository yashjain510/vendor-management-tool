import type React from "react"
import { useState } from "react"
import { useNavigate } from "react-router-dom"
import Header from "../components/Header"
import SearchBar from "../components/SearchBar"
import Pagination from "../components/Pagination"

interface RFIData {
  id: number
  name: string
  startDate: string
  endDate: string
  vendorName: string
  dateAdded: string
  lastUpdated: string
  status: "Active" | "Close"
}

const RFIQualified: React.FC = () => {
  const navigate = useNavigate()
  const [rfiData, setRfiData] = useState<RFIData[]>([
    {
      id: 1,
      name: "RFI Demo",
      startDate: "12-02-2024 5:30",
      endDate: "19-02-2024 5:30",
      vendorName: "Divya Ojha",
      dateAdded: "10-02-2024 2:30",
      lastUpdated: "11-02-2023 5:30",
      status: "Active",
    },
    {
      id: 2,
      name: "RFI Demo",
      startDate: "12-02-2024 5:30",
      endDate: "19-02-2024 5:30",
      vendorName: "Preet",
      dateAdded: "10-02-2024 2:30",
      lastUpdated: "11-02-2023 5:30",
      status: "Close",
    },
  ])

  return (
    <>
      <Header title="RFI Qualified" />
      <SearchBar />
      <table>
        <thead>
          <tr>
            <th>S.No</th>
            <th>RFI Name</th>
            <th>RFI Start Date</th>
            <th>RFI End Date</th>
            <th>Vendor Name</th>
            <th>Date Added</th>
            <th>Last Updated</th>
            <th>Status</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody>
          {rfiData.map((rfi) => (
            <tr key={rfi.id}>
              <td>{rfi.id}</td>
              <td>{rfi.name}</td>
              <td>{rfi.startDate}</td>
              <td>{rfi.endDate}</td>
              <td>{rfi.vendorName}</td>
              <td>{rfi.dateAdded}</td>
              <td>{rfi.lastUpdated}</td>
              <td>
                <span className={`status ${rfi.status.toLowerCase()}`}>{rfi.status}</span>
              </td>
              <td>
                <button className="action-button" onClick={() => navigate("/rfi-view")}>
                  👁️
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
      <Pagination />
    </>
  )
}

export default RFIQualified

