import type React from "react"
import { useState } from "react"
import { useNavigate } from "react-router-dom"
import Header from "../components/Header"

interface ActivityItem {
  id: number
  requirement: string
  value: string
  mandatory: string
  attachment: string
}

const RFIView: React.FC = () => {
  const navigate = useNavigate()
  const [activityList, setActivityList] = useState<ActivityItem[]>([
    { id: 1, requirement: "Laptop", value: "Number", mandatory: "Yes", attachment: "Yes" },
    { id: 2, requirement: "Mac Laptop", value: "Number", mandatory: "Yes", attachment: "No" },
  ])

  return (
    <>
      <Header title="RFI Approval > View" />
      <div className="info-grid">
        <div className="info-field">
          <div className="info-label">RFI Number</div>
          <input type="text" defaultValue="RFI Number 1" style={{ width: "100%", padding: "8px" }} />
        </div>
        <div className="info-field">
          <div className="info-label">Regarding</div>
          <input type="text" defaultValue="Laptop" style={{ width: "100%", padding: "8px" }} />
        </div>
        <div className="info-field">
          <div className="info-label">Responsible Person Name</div>
          <input type="text" defaultValue="Divya Ojha" style={{ width: "100%", padding: "8px" }} />
        </div>
        <div className="info-field">
          <div className="info-label">Responsible Person Email</div>
          <input type="email" defaultValue="qwer123@gmail.com" style={{ width: "100%", padding: "8px" }} />
        </div>
      </div>

      <div className="vendor-list">
        <div className="vendor-item">Divya Ojha</div>
        <div className="vendor-item">Divya Ojha</div>
        <div className="vendor-item">Divya Ojha</div>
        <div className="vendor-item">Divya Ojha</div>
      </div>

      <h3>Add RFI Activity List</h3>
      <table>
        <thead>
          <tr>
            <th>S.No</th>
            <th>Requirement</th>
            <th>Value</th>
            <th>Mandatory</th>
            <th>Attachment</th>
          </tr>
        </thead>
        <tbody>
          {activityList.map((item) => (
            <tr key={item.id}>
              <td>{item.id}</td>
              <td>{item.requirement}</td>
              <td>{item.value}</td>
              <td>{item.mandatory}</td>
              <td>{item.attachment}</td>
            </tr>
          ))}
        </tbody>
      </table>

      <div className="button-container">
        <button className="button" onClick={() => navigate("/")}>
          Back
        </button>
        <button className="button primary">Close</button>
      </div>
    </>
  )
}

export default RFIView

