import type React from "react"
import { useState } from "react"
import { useNavigate } from "react-router-dom"
import Header from "../components/Header"
import SearchBar from "../components/SearchBar"
import Pagination from "../components/Pagination"

interface RFIApprovalData {
  id: number
  name: string
  startDate: string
  endDate: string
  dateAdded: string
  lastUpdated: string
  status: string
  level: "Pending" | "Approved" | "Declined"
}

const RFIApproval: React.FC = () => {
  const navigate = useNavigate()
  const [approvalData, setApprovalData] = useState<RFIApprovalData[]>([
    {
      id: 1,
      name: "RFI Demo",
      startDate: "Chiku Organization",
      endDate: "Lorem",
      dateAdded: "Lorem",
      lastUpdated: "Lorem",
      status: "Active",
      level: "Pending",
    },
  ])

  const handleEdit = (id: number, field: keyof RFIApprovalData, value: string) => {
    setApprovalData(approvalData.map((item) => (item.id === id ? { ...item, [field]: value } : item)))
  }

  const handleLevelChange = (id: number, level: "Pending" | "Approved" | "Declined") => {
    setApprovalData(approvalData.map((item) => (item.id === id ? { ...item, level } : item)))
  }

  return (
    <>
      <Header title="RFI Approval" />
      <SearchBar />
      <table>
        <thead>
          <tr>
            <th>S.No</th>
            <th>RFI Name</th>
            <th>RFI Start Date</th>
            <th>RFI End Date</th>
            <th>Date Added</th>
            <th>Last Updated</th>
            <th>Status</th>
            <th>Level</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody>
          {approvalData.map((item) => (
            <tr key={item.id}>
              <td>{item.id}</td>
              <td contentEditable onBlur={(e) => handleEdit(item.id, "name", e.currentTarget.textContent || "")}>
                {item.name}
              </td>
              <td contentEditable onBlur={(e) => handleEdit(item.id, "startDate", e.currentTarget.textContent || "")}>
                {item.startDate}
              </td>
              <td contentEditable onBlur={(e) => handleEdit(item.id, "endDate", e.currentTarget.textContent || "")}>
                {item.endDate}
              </td>
              <td contentEditable onBlur={(e) => handleEdit(item.id, "dateAdded", e.currentTarget.textContent || "")}>
                {item.dateAdded}
              </td>
              <td contentEditable onBlur={(e) => handleEdit(item.id, "lastUpdated", e.currentTarget.textContent || "")}>
                {item.lastUpdated}
              </td>
              <td>
                <span className={`status ${item.status.toLowerCase()}`}>{item.status}</span>
              </td>
              <td>
                <select
                  value={item.level}
                  onChange={(e) => handleLevelChange(item.id, e.target.value as "Pending" | "Approved" | "Declined")}
                  style={{ padding: "4px", borderRadius: "4px" }}
                >
                  <option value="Pending">Pending</option>
                  <option value="Approved">Approved</option>
                  <option value="Declined">Declined</option>
                </select>
              </td>
              <td>
                <button className="action-button" onClick={() => navigate("/rfi-view")}>
                  👁️
                </button>
                <button className="action-button">✏️</button>
                <button className="action-button">⏹️</button>
                <button className="action-button">⏸️</button>
                <button className="action-button">🗑️</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
      <Pagination />
    </>
  )
}

export default RFIApproval

