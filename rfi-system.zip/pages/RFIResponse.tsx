import type React from "react"
import { useState } from "react"
import { useNavigate } from "react-router-dom"
import Header from "../components/Header"
import SearchBar from "../components/SearchBar"
import Pagination from "../components/Pagination"

interface RFIResponseData {
  id: number
  name: string
  startDate: string
  vendorsSent: number
  vendorsResponded: number
  dateAdded: string
  lastUpdated: string
  status: "Active" | "Close"
}

const RFIResponse: React.FC = () => {
  const navigate = useNavigate()
  const [responseData, setResponseData] = useState<RFIResponseData[]>([
    {
      id: 1,
      name: "RFI Demo",
      startDate: "Chiku Organization",
      vendorsSent: 4,
      vendorsResponded: 2,
      dateAdded: "Lorem",
      lastUpdated: "Lorem",
      status: "Active",
    },
  ])

  return (
    <>
      <Header title="RFI Response" />
      <SearchBar />
      <table>
        <thead>
          <tr>
            <th>S.No</th>
            <th>RFI Name</th>
            <th>RFI Start Date</th>
            <th>No Of vendor RFI sent</th>
            <th>No Of vendor response</th>
            <th>Date Added</th>
            <th>Last Updated</th>
            <th>Status</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody>
          {responseData.map((response) => (
            <tr key={response.id}>
              <td>{response.id}</td>
              <td>{response.name}</td>
              <td>{response.startDate}</td>
              <td>{response.vendorsSent}</td>
              <td>{response.vendorsResponded}</td>
              <td>{response.dateAdded}</td>
              <td>{response.lastUpdated}</td>
              <td>
                <span className={`status ${response.status.toLowerCase()}`}>{response.status}</span>
              </td>
              <td>
                <button className="action-button" onClick={() => navigate("/rfi-response-view")}>
                  👁️
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
      <Pagination />
    </>
  )
}

export default RFIResponse

