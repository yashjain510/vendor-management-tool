import type React from "react"
import { BrowserRouter as Router, Route, Routes } from "react-router-dom"
import Sidebar from "./components/Sidebar"
import RFIQualified from "./pages/RFIQualified"
import RFIView from "./pages/RFIView"
import RFIResponse from "./pages/RFIResponse"
import RFIResponseView from "./pages/RFIResponseView"
import RFIApproval from "./pages/RFIApproval"
import "./styles/global.css"

const App: React.FC = () => {
  return (
    <Router>
      <div style={{ display: "flex" }}>
        <Sidebar />
        <div className="main-content">
          <Routes>
            <Route path="/" element={<RFIQualified />} />
            <Route path="/rfi-view" element={<RFIView />} />
            <Route path="/rfi-response" element={<RFIResponse />} />
            <Route path="/rfi-response-view" element={<RFIResponseView />} />
            <Route path="/rfi-approval" element={<RFIApproval />} />
          </Routes>
        </div>
      </div>
    </Router>
  )
}

export default App

