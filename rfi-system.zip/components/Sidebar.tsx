import type React from "react"
import { useNavigate, useLocation } from "react-router-dom"

const Sidebar: React.FC = () => {
  const navigate = useNavigate()
  const location = useLocation()

  const menuItems = [
    { name: "Home", path: "/" },
    { name: "My Dashboard", path: "/dashboard" },
    { name: "Vendor Approval", path: "/vendor" },
    { name: "RFI", path: "/" },
    { name: "RFI Approval", path: "/rfi-approval" },
    { name: "RFI Response", path: "/rfi-response" },
    { name: "RFQ", path: "/rfq" },
    { name: "RFQ Approval", path: "/rfq-approval" },
    { name: "RFQ Response", path: "/rfq-response" },
  ]

  return (
    <div className="sidebar">
      <div className="logo">Work Web</div>
      {menuItems.map((item, index) => (
        <div
          key={index}
          className={`menu-item ${location.pathname === item.path ? "active" : ""}`}
          onClick={() => navigate(item.path)}
        >
          {item.name}
        </div>
      ))}
      <div className="menu-item">Log out</div>
    </div>
  )
}

export default Sidebar

