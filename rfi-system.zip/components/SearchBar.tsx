import type React from "react"

const SearchBar: React.FC = () => {
  return <input type="text" className="search-bar" placeholder="Search" />
}

export default SearchBar

